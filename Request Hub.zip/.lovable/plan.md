# Super Admin Dashboard — Plan

**Route:** `/super-admin`
**Persona:** Vikram Rathore (SA-001) · Chief Operating Officer
**Purpose:** Leadership view — final sign-off on high-value / queued requests + full spend visibility + budget control.

---

## 1. Role separation (cleanup)

| Dashboard | Focus | Change |
|---|---|---|
| Admin (John) | Day-to-day inbox, approve/reject/forward | Remove `/insights` from sidebar |
| Finance (Anjali) | Treasury — release funds | No change |
| **Super Admin (Vikram)** | Final approvals + Analytics + Budgets | **New** |
| Employee (Rahul) | Own requests | No change |

Sidebar `/insights` link → removed. Insights becomes a **tab inside Super Admin**.

---

## 2. Layout (tabbed single-page)

```text
┌─ Header: "Executive Console" · Vikram Rathore · SA-001 ────────────┐
│ KPI strip: Awaiting my approval · Approved today · Spend MTD ·     │
│            Budget utilization · Anomaly count                       │
├─────────────────────────────────────────────────────────────────────┤
│ Tabs:  [ Approval Queue ]  [ Insights ]  [ Budgets ]  [ Team ]     │
├─────────────────────────────────────────────────────────────────────┤
│                        (tab content here)                           │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 3. Tabs — what each shows

### Tab 1 — Approval Queue (default)
Requests forwarded by Admin (`status: "queued"`) awaiting final sign-off.
- Reuse existing `RequestRow` + `RequestDetail` split-view.
- Actions: **Final Approve** / **Reject** / **Send back to Admin**.
- Auto-signed log: `Final approval by Vikram Rathore (SA-001) · [time] IST`.
- Budget-impact banner in detail pane: "This ₹75,000 will consume 12% of Sales dept H2 budget."

### Tab 2 — Insights
Move current `/insights` page content here as-is (heatmap, dept bars, category mix, anomalies).

### Tab 3 — Budgets (new mini-feature)
Per-department caps with utilization bars.
- Table: Department · H2 Budget · Spent · Remaining · % Used · Trend arrow.
- Colour: green (<70%), amber (70-90%), red (>90%).
- Inline edit budget cap (mock, local state).
- Auto-flag when any dept crosses 85% → surfaced in KPI strip anomaly count.

### Tab 4 — Team (light)
Admin + Finance activity snapshot:
- John Admin: X approved / Y rejected / Z forwarded this week.
- Anjali Mehta: ₹X released, avg release time.
- Small avatar cards, no deep drill-down.

---

## 4. Files to create / edit

**New:**
- `src/routes/super-admin.tsx` — main route with tab state.
- `src/components/superadmin/ApprovalQueueTab.tsx` — reuses RequestRow/Detail.
- `src/components/superadmin/BudgetsTab.tsx` — budget table + editable caps.
- `src/components/superadmin/TeamTab.tsx` — admin/finance activity cards.
- `src/components/superadmin/InsightsTab.tsx` — extracted from current `/insights` page.

**Edit:**
- `src/components/DashboardLayout.tsx` — replace `/insights` nav item with `/super-admin` (label: "Super Admin", icon: `ShieldCheck`).
- `src/routes/index.tsx` — swap Insights tile for Super Admin tile.
- `src/routes/insights.tsx` — delete (content moves into InsightsTab).
- `src/components/MockData.ts` — add ~4 mock `queued` requests with realistic amounts so the queue isn't empty.

**No changes:** Admin, Finance, Employee routes stay exactly as they are.

---

## 5. Mock data additions

- Budget seed (in-file constant): 8 departments × H2 2026 cap + spent.
- 4 extra `queued` requests (₹50k–₹2L range) so approval queue has volume.
- Vikram's identity constant: `{ name: "Vikram Rathore", id: "SA-001", role: "Chief Operating Officer" }`.

---

## 6. Out of scope (for tomorrow)

- Real backend / API wiring.
- Budget history charts (just current period bars).
- Email/notifications when queue items arrive.
- Employee spend passport (feature #11 from earlier list — separate day).

---

## Estimate
One session, ~4 files new + 3 edited. No new dependencies.
